<?php
include('db_connection.php');
session_start();

if (!isset($_SESSION['teacher_id'])) {
    header("HTTP/1.1 401 Unauthorized");
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

$data = json_decode(file_get_contents('php://input'), true);
$section_id = $data['section_id'] ?? null;
$subject_ids = $data['subject_ids'] ?? [];

if (!$section_id || empty($subject_ids)) {
    header("HTTP/1.1 400 Bad Request");
    echo json_encode(['success' => false, 'message' => 'Missing required parameters']);
    exit();
}

try {
    // Get section information
    $sectionStmt = $conn->prepare("SELECT section_name, grade_level FROM sections WHERE id = ?");
    $sectionStmt->bind_param("i", $section_id);
    $sectionStmt->execute();
    $sectionData = $sectionStmt->get_result()->fetch_assoc();
    
    if (!$sectionData) {
        throw new Exception("Section not found");
    }
    
    // Get all students in the section
    $studentStmt = $conn->prepare("
        SELECT lrn, first_name, middle_name, last_name, rfid 
        FROM students 
        WHERE section = ?
    ");
    $studentStmt->bind_param("s", $sectionData['section_name']);
    $studentStmt->execute();
    $students = $studentStmt->get_result()->fetch_all(MYSQLI_ASSOC);
    
    if (empty($students)) {
        echo json_encode(['success' => false, 'message' => 'No students found in this section']);
        exit();
    }

    // Check teacher assignments before starting transaction
    $subjectsWithoutTeachers = [];
    $subjectsWithTeachers = [];
    
    foreach ($subject_ids as $subject_id) {
        $teacherStmt = $conn->prepare("
            SELECT ts.teacher_id, f.name as teacher_name
            FROM teacher_subjects ts
            LEFT JOIN faculty f ON ts.teacher_id = f.id
            WHERE ts.subject_id = ? 
            AND ts.section_id = ?
            LIMIT 1
        ");
        $teacherStmt->bind_param("ii", $subject_id, $section_id);
        $teacherStmt->execute();
        $teacherData = $teacherStmt->get_result()->fetch_assoc();
        
        if (!$teacherData || !$teacherData['teacher_id']) {
            $subjectsWithoutTeachers[] = $subject_id;
        } else {
            $subjectsWithTeachers[$subject_id] = [
                'teacher_id' => $teacherData['teacher_id'],
                'teacher_name' => $teacherData['teacher_name']
            ];
        }
    }

    // If any subjects lack teachers, return warning immediately
    if (!empty($subjectsWithoutTeachers)) {
        // Get subject names for the warning message
        $subjectNames = [];
        $subjectStmt = $conn->prepare("SELECT subject_name FROM subjects WHERE id IN (".implode(',', array_fill(0, count($subjectsWithoutTeachers), '?')).")");
        $subjectStmt->bind_param(str_repeat('i', count($subjectsWithoutTeachers)), ...$subjectsWithoutTeachers);
        $subjectStmt->execute();
        $subjectResult = $subjectStmt->get_result();
        while ($row = $subjectResult->fetch_assoc()) {
            $subjectNames[] = $row['subject_name'];
        }
        
        echo json_encode([
            'success' => false,
            'message' => 'Cannot proceed with enrollment',
            'warning' => 'The following subjects have no assigned teachers: ' . implode(', ', $subjectNames),
            'subjects_without_teachers' => $subjectsWithoutTeachers
        ]);
        exit();
    }

    $conn->begin_transaction();

    // Prepare the insert statement
    $insertStmt = $conn->prepare("
        INSERT INTO student_enrollments 
        (student_lrn, student_name, rfid, section_name, grade_level, 
         subject_id, section_id, teacher_id, subject_name, teacher_name) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");

    foreach ($students as $student) {
        $full_name = $student['first_name'] . ' ' . 
                    ($student['middle_name'] ? $student['middle_name'] . ' ' : '') . 
                    $student['last_name'];
        
        foreach ($subject_ids as $subject_id) {
            // Get subject name
            $subjectStmt = $conn->prepare("SELECT subject_name FROM subjects WHERE id = ?");
            $subjectStmt->bind_param("i", $subject_id);
            $subjectStmt->execute();
            $subjectData = $subjectStmt->get_result()->fetch_assoc();
            $subject_name = $subjectData['subject_name'];
            
            // Use pre-fetched teacher data
            $teacherData = $subjectsWithTeachers[$subject_id];
            
            $insertStmt->bind_param(
                "sssssiiiss",
                $student['lrn'],
                $full_name,
                $student['rfid'],
                $sectionData['section_name'],
                $sectionData['grade_level'],
                $subject_id,
                $section_id,
                $teacherData['teacher_id'],
                $subject_name,
                $teacherData['teacher_name']
            );
            
            if (!$insertStmt->execute()) {
                throw new Exception("Failed to insert enrollment: " . $insertStmt->error);
            }
        }
    }

    $conn->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'Bulk enrollment completed for ' . count($students) . ' students',
        'students_count' => count($students),
        'subjects_count' => count($subject_ids)
    ]);
} catch (Exception $e) {
    $conn->rollback();
    header("HTTP/1.1 500 Internal Server Error");
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>